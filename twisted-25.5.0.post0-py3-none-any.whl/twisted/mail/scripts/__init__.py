"mail scripts"
