"conch scripts"
