"Tests for twisted.names"
